USE clinic;
/*manger queries*/

select  patient_name ,patient_id
from patient, visit_of_a_patient
where patient.patient_id=visit_of_a_patient.visit_of_a_patient_id and visit_of_a_patient_date ='2019-01-01'  ;



select count(shift_day) as 'numbers of shifts', doctor.doctor_name,doctor.doctor_id
from scheduling, doctor
where scheduling.doctor_id= doctor.doctor_id 
group by doctor.doctor_id
having  count(shift_day)>1;



 SELECT DISTINCT doctor.doctor_id,doctor_name, scheduling.getting_started_date,doctor_Specialty
 FROM scheduling,doctor
 WHERE scheduling.doctor_id=doctor.doctor_id and getting_started_date = (SELECT min(getting_started_date) FROM scheduling);




select patient_name, patient_id ,TIMESTAMPDIFF(year, visit_of_a_patient_date , CURDATE() ) as Time_from_last_visit_is_years
from patient,visit_of_a_patient
where patient.patient_id = visit_of_a_patient.visit_of_a_patient_id
ORDER BY Time_from_last_visit_is_years desc;


select Employee_name, Employee_phone
from Employee
where Employee_phone not like '%054%';



select Employee.Employee_name, Employee.Employee_adress, E1.Employee_name 
from Employee, Employee as E1
where Employee.Employee_name != E1.Employee_name and Employee.Employee_adress=E1.Employee_adress
group by Employee_adress;


update doctor
set doctor_Specialty='eyes'  /*change doctor_Specialty for dr itay*/
where doctor_id='318595618';

select * 
from doctor;


delete from scheduling
where doctor_id='318595618'; /* delete only in scheduling table*/

select *
from scheduling;

/*--------------------------------------------------------------------------------------------------------------------------------*/

/*doctor queries*/

 SELECT DISTINCT visit_of_a_patient_id,patient_name, usage_time_in_days,medication_name
 FROM prescription,visit_of_a_patient, patient,medication
 WHERE prescription.visit_code=visit_of_a_patient.visit_code and patient.patient_id=visit_of_a_patient.visit_of_a_patient_id
and medication.medication_code=prescription.medication_code 
and usage_time_in_days = (SELECT max(usage_time_in_days) FROM prescription) ;



select  distinct visit_of_a_patient_id, patient_name
from patient, visit_of_a_patient, referral, medical_examination
where patient.patient_id = visit_of_a_patient.visit_of_a_patient_id and visit_of_a_patient.visit_code=referral.visit_code 
and referral.examination_code=medical_examination.examination_code and examination_info= "Dentistry problems";


select  t1.patient_name,  t1.medication_name,  t2.patient_name 
from  
(select patient_name, medication.medication_name
from patient, prescription, medication, visit_of_a_patient
where patient.patient_id=visit_of_a_patient.visit_of_a_patient_id 
and visit_of_a_patient.visit_code= prescription.visit_code 
and prescription.medication_code=medication.medication_code) t1,
(select patient_name, medication.medication_name
from patient, prescription, medication, visit_of_a_patient
where patient.patient_id=visit_of_a_patient.visit_of_a_patient_id 
and visit_of_a_patient.visit_code= prescription.visit_code 
and prescription.medication_code=medication.medication_code) t2
where t1.patient_name!=t2.patient_name and t1.medication_name=t2.medication_name
group by  t1.medication_name;



select r1.patient_name, r1.diagnosis_info, r2. patient_name
from (select patient_name, diagnosis_info
from patient, visit_of_a_patient, diagnosis_visitation_of_patients, diagnosis
where patient.patient_id=visit_of_a_patient.visit_of_a_patient_id 
and visit_of_a_patient.visit_code=diagnosis_visitation_of_patients.visit_code
and diagnosis_visitation_of_patients.diagnosis_code=diagnosis.diagnosis_code) r1,
(select patient_name, diagnosis_info
from patient, visit_of_a_patient, diagnosis_visitation_of_patients, diagnosis
where patient.patient_id=visit_of_a_patient.visit_of_a_patient_id 
and visit_of_a_patient.visit_code=diagnosis_visitation_of_patients.visit_code
and diagnosis_visitation_of_patients.diagnosis_code=diagnosis.diagnosis_code) r2
where r1.patient_name !=r2. patient_name and r1.diagnosis_info=r2.diagnosis_info
group by r2.diagnosis_info;


select distinct patient_name, patient_id,examination_place
from patient, visit_of_a_patient,referral,medical_examination
where patient.patient_id = visit_of_a_patient.visit_of_a_patient_id  and visit_of_a_patient.visit_code = referral.visit_code
and referral.examination_code = medical_examination.examination_code
and examination_place = "Beilinson";


select patient_name, patient_id
from patient, visit_of_a_patient , prescription, medication
where  patient.patient_id = visit_of_a_patient.visit_of_a_patient_id
 and  visit_of_a_patient.visit_code=prescription.visit_code 
and prescription.medication_code= medication.medication_code
and medication_name= 'NO medication';



update prescription
set medication_amount_in_day = 2 ,usage_time_in_days = 7 
/*change  medication_amount_in_day and usage_time_in_days for patient alon*/
where visit_code =123;

select *
from prescription;


update visit_of_a_patient
set visit_of_a_patient_date = '2020-12-31'
where visit_code =123;


select *
from visit_of_a_patient;

