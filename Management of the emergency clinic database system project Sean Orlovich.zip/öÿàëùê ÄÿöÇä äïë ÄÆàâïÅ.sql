CREATE SCHEMA clinic;
USE clinic;

CREATE TABLE Employee
(Employee_id int(20) not null,
Employee_name varchar(20),
Employee_adress varchar(20),
Employee_phone varchar(10),
PRIMARY KEY (Employee_id)
)engine=innodb;

CREATE TABLE doctor
(doctor_id int(20) not null,
doctor_name varchar(10),
doctor_Specialty varchar(50),
PRIMARY KEY (doctor_id),
FOREIGN KEY (doctor_id) REFERENCES Employee(Employee_id) on update cascade
)engine=innodb;

CREATE TABLE medical_staff
(staff_id int(20) not null,
name_staff varchar(10),
staff_role varchar(20),
staff_profession varchar(20),
PRIMARY KEY (staff_id),
FOREIGN KEY (staff_id) REFERENCES Employee(Employee_id) 
)engine=innodb;

CREATE TABLE patient
(patient_id int(20) not null,
patient_name varchar(20),
patient_adress varchar(20),
patient_phone int(10),
PRIMARY KEY (patient_id)
)engine=innodb;

CREATE TABLE visit_of_a_patient
(visit_code int(25) not null,
visit_of_a_patient_id int(25),
visit_of_a_patient_doctor_id int(25),
visit_of_a_patient_date date,
PRIMARY KEY (visit_code),
FOREIGN KEY (visit_of_a_patient_id) REFERENCES patient(patient_id) on update cascade ,
FOREIGN KEY (visit_of_a_patient_doctor_id) REFERENCES doctor(doctor_id) on update cascade
)engine=innodb;

CREATE TABLE medication
(medication_code int(25) not null,
medication_name varchar(20),
PRIMARY KEY (medication_code)
)engine=innodb;

CREATE TABLE prescription
(visit_code int(25) not null,
medication_code int(25) not null,
medication_amount_in_day int(20),
usage_time_in_days int(10),
PRIMARY KEY(visit_code ,medication_code),
FOREIGN KEY (visit_code) REFERENCES visit_of_a_patient(visit_code) on update cascade,
FOREIGN KEY (medication_code) REFERENCES medication(medication_code) on update cascade
)engine=innodb;

CREATE TABLE diagnosis
(diagnosis_code int(25) not null,
diagnosis_info varchar(50),
PRIMARY KEY(diagnosis_code)
)engine=innodb;

CREATE TABLE diagnosis_visitation_of_patients
(visit_code int(25) not null,
diagnosis_code int(25),
PRIMARY KEY(visit_code,diagnosis_code),
FOREIGN KEY (visit_code) REFERENCES visit_of_a_patient(visit_code),
FOREIGN KEY (diagnosis_code) REFERENCES diagnosis(diagnosis_code)
)engine=innodb;

CREATE TABLE medical_examination
(examination_code int(25) not null,
examination_info varchar(50),
examination_place varchar(20),
PRIMARY KEY (examination_code)
)engine=innodb;

CREATE TABLE referral 
(visit_code int(25) not null,
examination_code int(25),
validity_referral_in_days int(10),
PRIMARY KEY(visit_code,examination_code),
FOREIGN KEY (visit_code) REFERENCES visit_of_a_patient(visit_code),
FOREIGN KEY (examination_code) REFERENCES medical_examination(examination_code)
)engine=innodb;

CREATE TABLE scheduling
(getting_started_date date not null,
doctor_id int(20) not null,
shift_start_time time,
shift_end_time time,
shift_day varchar(10),
FOREIGN KEY (doctor_id) REFERENCES doctor(doctor_id) on delete cascade
)engine=innodb;


INSERT INTO Employee VALUES
(318595618,"itay","kiryat ono",'0508585556'),
(206171068,"sean","Petah Tikva",'0544652222'),
(23909013,"helen","Herzliya",'0545691563'),
(22971691,"michal","Tel Aviv",'0504455174'),
(22643886,"lior","savyon", '0524286316'),
(02678712,"nir","Tel Aviv", '0504455175'),
(208791690,"aviv","Rishon Lezion",'0528714888'),
(207875639,"yanir","Petah Tikva",'0524346009'),
(325614312,"sophia","bat yam",'0524776181'),
(371971798,"victoria","holon",'0502222744');

INSERT INTO doctor VALUES
(318595618,"itay","Orthopedics"),
(206171068,"sean","Gynecology"),
(325614312,"sophia","Dermatology"),
(371971798,"victoria","Dentistry");

INSERT INTO medical_staff VALUES
(23909013,"helen","Nurse","paramedic"),
(22971691,"michal","Nurse","Medical assistant"),
(22643886,"lior","Nurse","paramedic"),
(02678712,"nir","Nurse", "physiotherapy"),
(208791690,"aviv","Ambulance driver",null),
(207875639,"yanir","official", null);

INSERT INTO patient VALUES
(123456789,"alon","kiryat ono",0501234567),
(123456788,"yaron","Herzliya",0541234567),
(123456777,"roei","Or Yehuda",0545987865),
(123456787,"mika","Tel Aviv",0507897567),
(321456987,"efi","Yehud", 0527748997),
(147258369,"iris","Tel Aviv", 0504447875),
(296325874,"ayelet","Rosh HaAyin",0528888678),
(357951123,"haim","ganey tikva",0526543987),
(159753367,"boaz","bat yam",0527412596),
(231258745,"yael","Netanya", 0526547893),
(111478954,"dvora","Tel Aviv", 0509865312),
(686893258,"yoni","Rishon Lezion",0527329865),
(875421369,"david","Petah Tikva",0524589623),
(258963388,"efrat","ramat gan",0524875129),
(178039677,"eyal","jerusalem",0504856932);


INSERT INTO visit_of_a_patient VALUES
(123,123456789,318595618,'2019-01-01'),
(124,123456788,318595618,'2019-02-01'),
(125,123456777,318595618,'2018-12-01'),
(126,123456787,206171068,'2018-11-01'),
(127,321456987,206171068,'2016-01-01'),
(128,147258369,206171068,'2010-02-01'),
(129,296325874,325614312,'2011-11-01'),
(130,357951123,325614312,'2011-10-01'),
(131,159753367,325614312,'2018-05-01'),
(132,231258745,371971798,'2016-04-01'),
(133,111478954,371971798,'2019-01-01'),
(134,686893258,371971798,'2020-01-01'),
(135,875421369,371971798,'2019-03-17'),
(136,258963388,371971798,'2017-10-27'),
(137,178039677,371971798,'2013-10-20');

INSERT INTO medication VALUES
(00,"NO medication"),
(12,"Moxypen"),
(13,"Arcoxia"),
(14,"Voltaren"),
(15,"Decapeptyl"),
(16,"Synarel"),
(17,"Superfact"),
(18,"Aknemycin"),
(19,"Daivobet"),
(20,"Xamiol"),
(21,"Optalgin"),
(22,"Advil"),
(23,"Nurofen"),
(24,"PARACETAMOL"),
(25,"Aspirin");

INSERT INTO prescription VALUES
(123,12,3,14),
(124,13,2,7),
(125,14,2,21),
(126,15,1,7),
(127,16,4,30),
(128,17,2,7),
(129,18,3,10),
(130,19,2,21),
(131,20,2,12),
(131,21,2,14),
(132,22,1,20),
(133,00,null,null),
(134,23,2,7),
(135,24,1,30),
(136,25,1,10),
(137,25,1,10),
(125,15,1,7);

INSERT INTO diagnosis VALUES
(0000, "NO diagnosis"),
(1224,"back Pain"),
(1334,"neck Pain"),
(1423,"knee Pain"),
(1552,"fertility problems"),
(1661,"pregnancy"),
(1772,"fertilization"),
(1812,"Facial sores"),
(1956,"Skin dryness"),
(2012,"Psoriasis"),
(2332,"Toothache"),
(2212,"wisdom tooth"),
(2323,"displacement"),
(2423,"Crown"),
(2512,"Cavity");

INSERT INTO diagnosis_visitation_of_patients VALUES
(123,1224),
(124,1334),
(125,1423),
(126,1552),
(127,1661),
(128,1772),
(129,1812),
(130,1956),
(131,2012),
(131,2332),
(132,2212),
(133,0000),
(134,2323),
(135,2423),
(136,2512),
(137,2512),
(125,1552);

INSERT INTO medical_examination VALUES
(00000,"No problems", "NO place"),
(11111,"Orthopedics problems","Assuta"),
(22222,"Orthopedics problems","Tel Ha Shomer"),
(33333,"Orthopedics problems","Tel Ha Shomer"),
(44444,"Gynecology problems","Tel Ha Shomer"),
(55555,"Gynecology problems","Beilinson"),
(66666,"Gynecology problems","Beilinson"),
(77777,"Dermatology problems","Beilinson"),
(88888,"Dermatology problems","Hadassah"),
(99999,"Dermatology problems","Hadassah"),
(01011,"Dentistry problems","Hadassah"),
(02022,"Dentistry problems","Hadassah"),
(03033,"Dentistry problems","Hadassah"),
(04044,"Dentistry problems","Assaf Harofeh"), 
(05055,"Dentistry problems","Assuta");

INSERT INTO referral VALUES
(123,11111,90),
(124,22222,30),
(125,33333,45),
(126,44444,60),
(127,55555,30),
(128,66666,660),
(129,77777,90),
(130,88888,90),
(131,99999,15),
(131,01011,21),
(132,02022,90),
(133,00000,null),
(134,03033,45),
(135,04044,120),
(136,05055,90),
(137,05055,90),
(125,44444,60);

INSERT INTO scheduling VALUES
('1997-07-30',318595618,0800,1800,"Sunday"),
('1995-06-21',206171068,0800,1800,"Monday"),
('2000-08-25',325614312,0800,1800,"Tuesday"),
('1997-12-08',371971798,0800,1800,"Wednesday"),
('1997-07-30',318595618,0800,1300,"Thursday"),
('1995-06-21',206171068,1300,1800,"Thursday");